See a complete blog post that builds this example on [my website](https://www.bensampica.com/post/minimalapihtmx).
